import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:huawei_ads/huawei_ads.dart';
import 'package:huawei_ads_template/screens/banner_ad_screen.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  try {

      await HwAds.init();
      await VastSdkFactory.init(VastSdkConfiguration(isTest: true),
      );

      // await VastSdkFactory.userAcceptAdLicense(false);
  }
  catch (error) {
    log("error $error");
  }
  runApp( const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: BannerAdScreen(),
    );
  }
}
