import 'package:flutter/material.dart';
import 'package:huawei_ads/huawei_ads.dart';

import 'helper/banner_ad_huawei.dart';
import 'native_ad_screen.dart';

class BannerAdScreen extends StatefulWidget {
  const BannerAdScreen({super.key});

  @override
  HomePageState createState() => HomePageState();
}


class HomePageState extends State<BannerAdScreen> {

  BannerAd? _bannerAd;

  @override
  void initState() {
    super.initState();
    _bannerAd?.destroy();


    WidgetsBinding.instance.addPostFrameCallback((_) async {
      _bannerAd = BannerAdHuawei.createAd();

      await _bannerAd!.loadAd();
      await _bannerAd!.show(
        offset: 90.0,
        gravity: Gravity.center
      );
    });
  }

  @override
  void dispose() {
    super.dispose();
    _bannerAd?.destroy();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("Huawei Ads Template",
        style: TextStyle(
          color: Colors.white,
        ),),
      ),
      body:  Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [



          const Center(
            child: Text("Banner Screen", style: TextStyle(
              color: Colors.black,
              fontSize: 24,
            ),),
          ),



          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: InkWell(
                onTap: () {
                  _bannerAd!.destroy();
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const NativeAdScreen()));
                },
                child: Container(
                  width: MediaQuery.sizeOf(context).width,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.deepOrangeAccent,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: const Center(
                    child: Text("Native Ads", style: TextStyle(color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),),
                  ),
                ),
              ),
            ),
          )

        ],
      ),
    );
  }
}
