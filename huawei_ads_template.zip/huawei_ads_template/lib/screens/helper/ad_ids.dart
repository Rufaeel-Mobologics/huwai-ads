import 'dart:io';

class AdHelperHuawei {
  static String get bannerAd {
    if (Platform.isAndroid) {
      return 'testw6vs28auh3';
    }
    throw UnsupportedError("Unsupported platform");
  }
  static String get nativeImageAd {
    if (Platform.isAndroid) {
      return 'testu7m3hc4gvm';
    }
    throw UnsupportedError("Unsupported platform");
  }
  static String get nativeVideoAd {
    if(Platform.isAndroid) {
      return 'testy63txaom86';
    }
    throw UnsupportedError("Unsupported platform");
  }

}

//
// static String get interstitialAd {
//   if (Platform.isAndroid) {
//     return 'ca-app-pub-3728514030691835/8127005052';
//   }
//   throw UnsupportedError("Unsupported platform");
// }
//
// static String get interstitialAdSplash {
//   if (Platform.isAndroid) {
//     return 'ca-app-pub-3728514030691835/4187760040';
//   }
//   throw UnsupportedError("Unsupported platform");
// }
//
// static String get nativeAd {
//   if (Platform.isAndroid) {
//     return 'ca-app-pub-3728514030691835/1611883384';
//   }
//   throw UnsupportedError("Unsupported platform");
// }
//
// static String get nativeAdSplash {
//   if (Platform.isAndroid) {
//     return 'ca-app-pub-3728514030691835/7935433369';
//   }
//   throw UnsupportedError("Unsupported platform");
// }
//
// static String get openAppAd {
//   if (Platform.isAndroid) {
//     return 'ca-app-pub-3728514030691835/2921197027';
//   } 'ca-app-pub-3940256099942544/5662855259';
//   throw UnsupportedError("Unsupported platform");
// }