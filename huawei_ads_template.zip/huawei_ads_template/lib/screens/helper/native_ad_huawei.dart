import 'dart:developer';

import 'package:huawei_ads/huawei_ads.dart';
import 'package:huawei_ads_template/screens/helper/ad_ids.dart';

class NativeAdHuawei {


  static final AdParam _adParam = AdParam();
  static BannerAdSize? bannerAdSize = BannerAdSize.s320x50;

  static BannerAd createAd() {
    return BannerAd(
      adSlotId: AdHelperHuawei.bannerAd,
      size: bannerAdSize!,
      adParam: _adParam,
      bannerRefreshTime: 5000,
      listener: (AdEvent event, {int? errorCode}) {
        log("error Code $errorCode");
      },
    );
  }





}