import 'package:flutter/material.dart';
import 'package:huawei_ads/huawei_ads.dart';
import 'package:huawei_ads_template/screens/helper/ad_ids.dart';

class NativeAdScreen extends StatefulWidget {
  const NativeAdScreen({super.key});

  @override
  State<NativeAdScreen> createState() => _NativeAdScreenState();
}

class _NativeAdScreenState extends State<NativeAdScreen> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("Native Ads", style: TextStyle(color: Colors.white),),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
        
            const SizedBox(
              height: 8,
            ),
        
            Text("Native Bannder Ad",
              style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 18
            ),
            ),
        
        
            Container(
              height: 450,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              margin: const EdgeInsets.only(bottom: 40.0),
              child: NativeAd(
                adSlotId: AdHelperHuawei.nativeImageAd,
                controller: NativeAdController(
                  adConfiguration: NativeAdConfiguration(
                    choicesPosition:
                    NativeAdChoicesPosition.BOTTOM_RIGHT,
                  ),
                  listener: (AdEvent event, {int? errorCode}) {
                    debugPrint('Native Ad event : $event');
                  },
                ),
                type: NativeAdType.banner,
              ),
            ),
        
            Divider(),
        
            Container(
              padding: const EdgeInsets.symmetric(vertical: 20),
              color: Colors.black12,
              child: const Center(
                child: Text(
                  'Native Small Ad',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 18
                  ),
                ),
              ),
            ),
            Container(
              height: 100,
              margin: const EdgeInsets.only(bottom: 20.0),
              child: NativeAd(
                adSlotId: AdHelperHuawei.nativeImageAd,
                controller: NativeAdController(),
                type: NativeAdType.full,
                styles: NativeStyles()
                  ..setTitle(fontWeight: NativeFontWeight.boldItalic)
                  ..setCallToAction(fontSize: 8)
                  ..setFlag(fontSize: 10)
                  ..setSource(fontSize: 11),
              ),
            ),

            Divider(),

            SizedBox(
              height: 8,
            ),

            Container(
              padding: const EdgeInsets.symmetric(vertical: 20),
              color: Colors.black12,
              child: const Center(
                child: Text(
                  'Native Ad Full Vide',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 18
                  ),
                ),
              ),
            ),

            Container(
              height: 400,
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.only(bottom: 20.0),
              child: NativeAd(
                adSlotId: AdHelperHuawei.nativeVideoAd,
                controller: NativeAdController(),
                type: NativeAdType.full,
                styles: NativeStyles()
                  ..setSource(color: Colors.redAccent)
                  ..setCallToAction(
                    color: Colors.white,
                    bgColor: Colors.redAccent,
                  ),
              ),
            ),


            const SizedBox(
              height: 50,
            ),


        
          ],
        ),
      ),
    );
  }
}
